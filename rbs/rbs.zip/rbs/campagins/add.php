<?php
include '../connect.php';
$agent_id   =  filterRequest('agent_id');      //1
$name         =  filterRequest('name');            //2
$link         =  filterRequest('link');            //4
$active       =  filterRequest('active');          //5
$start_date   =  filterRequest('start_date');      //6
$end_date     =  filterRequest('end_date');        //7
    $stmt = $con->prepare("INSERT INTO `campaigns`(`agent_id`, `name`, `link`, `active`, `start_date`, `end_date`) VALUES (?,?,?,?,?,?)");
    $stmt->execute(array($agent_id, $name, $link, $active, $start_date, $end_date ));
    $cont = $stmt->rowCount();
if($cont > 0){
    echo json_encode(array('status' => 'suc'));
}else{
    echo json_encode(array('status' => 'fail'));
}
?>