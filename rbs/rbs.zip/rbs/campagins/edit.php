<?php
include '../connect.php';
$agent_id   =  filterRequest('agent_id');      //1
$name          =  filterRequest('name');              //2
$id           =  filterRequest('id');              //2
$link         =  filterRequest('link');            //4
$start_date   =  filterRequest('start_date');      //6
$end_date     =  filterRequest('end_date');        //7
    $stmt = $con->prepare("UPDATE `campaigns` SET `agent_id`=?, `name`=?, `link`=?, `start_date`=?, `end_date`=? WHERE `id`=?");
    $stmt->execute(array($agent_id, $name, $link, $start_date, $end_date ,$id));
    $cont = $stmt->rowCount();
if($cont > 0){
    echo json_encode(array('status' => 'suc'));
}else{
    echo json_encode(array('status' => 'fail'));
}
?>