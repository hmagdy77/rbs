<?php
include '../connect.php';
$start      =  filterRequest('start'); //1
$end        =  filterRequest('end');   //2
$agent_id   =  filterRequest('agent_id');   //2
$stmt = $con->prepare("SELECT * FROM `reports` WHERE `agent_id` = ? and `date` between ? and ?");
$stmt->execute(array($agent_id, $start, $end));
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);
$cont = $stmt->rowCount();
if($cont > 0){
    echo json_encode(array('status' => 'suc', 'data' =>$data));
}else{
    echo json_encode(array('status' => 'fail', 'data' =>$data));
}
?>