<?php
include '../connect.php';
$emp_name     = filterRequest('emp_name');     //1
$day     = filterRequest('day');     //1
$emp_exit     = filterRequest('emp_exit');     //1
$stmt = $con->prepare("UPDATE `attend` SET  `emp_exit`=?, `is_exit` = '1' WHERE `emp_name` = ? AND `day` = ?");
$stmt->execute(array($emp_exit, $emp_name ,$day));
$cont = $stmt->rowCount();
if($cont > 0){
echo json_encode(array('status' => 'suc'));
}else{
echo json_encode(array('status' => 'fail'));
}
?> 