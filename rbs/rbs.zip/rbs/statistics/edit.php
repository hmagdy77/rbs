<?php
include '../connect.php';
    $messages     =  filterRequest('messages');      //2
    $reach        =  filterRequest('reach');         //3
    $comments     =  filterRequest('comments');      //4
    $likes        =  filterRequest('likes');         //5
    $id           =  filterRequest('id');            //7
    $stmt = $con->prepare("UPDATE `statistics` SET `messages`=?,`reach`=?,`comments`=?,`likes`=? WHERE `id`=?");
    $stmt->execute(array($messages, $reach, $comments, $likes, $id));
    $cont = $stmt->rowCount();
    if($cont > 0){
        echo json_encode(array('status' => 'suc'));
    }else{
        echo json_encode(array('status' => 'fail'));
    }
?>