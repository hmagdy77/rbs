<?php
include '../connect.php';
$campaign_id  = filterRequest('campaign_id');   
$stmt = $con->prepare("SELECT SUM(comments) from statistics where `campaign_id`=?");
$stmt->execute(array($campaign_id));
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);
$cont = $stmt->rowCount();
if($cont > 0){
    echo json_encode(array('status' => 'suc', 'data' =>$data));
}else{
    echo json_encode(array('status' => 'fail', 'data' =>$data));
}
?>