<?php
include '../connect.php';
$user_id        = filterRequest('user_id');  
$user_name      = filterRequest('user_name');  
$user_password  = filterRequest('user_password');  
$user_admin     = filterRequest('user_admin');  
$emp            = filterRequest('emp');  
$stmt = $con->prepare("UPDATE `users` SET `user_name`=?,`user_password`=?, `user_admin`=?, `emp`=? WHERE `user_id`=?");
$stmt->execute(array($user_name, $user_password, $user_admin, $emp, $user_id));
$cont = $stmt->rowCount();
if($cont > 0){
    echo json_encode(array('status' => 'suc'));
}else{
    echo json_encode(array('status' => 'fail'));
}
?>

