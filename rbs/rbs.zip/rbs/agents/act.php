<?php
include '../connect.php';
$id              =  filterRequest('id');              //1
$active          =  filterRequest('active');          //2
    $stmt = $con->prepare("UPDATE `agents` SET `active`=?  WHERE  `id`=? ");
    $stmt->execute(array($active , $id));
    $cont = $stmt->rowCount();
if($cont > 0){
    echo json_encode(array('status' => 'suc'));
}else{
    echo json_encode(array('status' => 'fail'));
}
?>