<?php
include '../connect.php';
$title        =  filterRequest('title');       //1
$content      =  filterRequest('content');     //2
$creater      =  filterRequest('creater');     //3
$agent        =  filterRequest('agent');       //4
$seen         =  filterRequest('seen');       //4
$stmt = $con->prepare("INSERT INTO `alerts`(`title`, `content`, `creater`, `agent`, `seen`) VALUES (?,?,?,?,?)");
$stmt->execute(array($title, $content, $creater, $agent, $seen));
$cont = $stmt->rowCount();
    if($cont > 0){
    echo json_encode(array('status' => 'suc'));
}   else{
    echo json_encode(array('status' => 'fail'));
}
?>

